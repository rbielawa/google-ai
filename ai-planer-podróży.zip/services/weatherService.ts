
import { WeatherData, Coordinates } from "../types";

const weatherCodes: Record<number, { condition: string; icon: string; description: string }> = {
  0: { condition: "Clear", icon: "Sun", description: "Czyste niebo" },
  1: { condition: "Mainly Clear", icon: "CloudSun", description: "Przeważnie pogodnie" },
  2: { condition: "Partly Cloudy", icon: "CloudSun", description: "Częściowe zachmurzenie" },
  3: { condition: "Overcast", icon: "Cloud", description: "Pochmurno" },
  45: { condition: "Fog", icon: "CloudFog", description: "Mgła" },
  48: { condition: "Depositing Rime Fog", icon: "CloudFog", description: "Mgła osadzająca szadź" },
  51: { condition: "Drizzle", icon: "CloudDrizzle", description: "Lekka mżawka" },
  61: { condition: "Rain", icon: "CloudRain", description: "Lekki deszcz" },
  63: { condition: "Rain", icon: "CloudRain", description: "Deszcz" },
  71: { condition: "Snow", icon: "CloudSnow", description: "Opady śniegu" },
  95: { condition: "Thunderstorm", icon: "CloudLightning", description: "Burza" },
};

export const fetchCurrentWeather = async (coords: Coordinates): Promise<WeatherData> => {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lng}&current_weather=true`;
    const response = await fetch(url);
    const data = await response.json();
    
    const current = data.current_weather;
    const codeInfo = weatherCodes[current.weathercode] || { condition: "Unknown", icon: "Cloud", description: "Zmienna pogoda" };

    return {
      temp: Math.round(current.temperature),
      condition: codeInfo.condition,
      icon: codeInfo.icon,
      description: codeInfo.description
    };
  } catch (error) {
    console.error("Failed to fetch weather:", error);
    throw error;
  }
};
