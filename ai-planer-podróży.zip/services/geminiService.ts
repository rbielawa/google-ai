
import { GoogleGenAI, Type } from "@google/genai";
import { Place, TravelTime, UserPreferences, DayPlan } from "../types";

export const generateDayPlan = async (
  places: Place[],
  travelMatrix: any[], // Przekazujemy pustą tablicę, Gemini samo oceni dystans na podstawie współrzędnych
  preferences: UserPreferences
): Promise<DayPlan> => {
  // Fix: Create a new GoogleGenAI instance inside the function call to ensure it uses the latest API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";

  const prompt = `
    Jesteś ekspertem od planowania podróży. Stwórz optymalny plan dnia dla wycieczki.
    
    PUNKT STARTOWY (Zawsze zaczynaj od tego miejsca):
    - Nazwa: ${preferences.startLocation.name}
    - Współrzędne: ${preferences.startLocation.coordinates.lat}, ${preferences.startLocation.coordinates.lng}

    LISTA MIEJSC DOCELOWYCH:
    ${JSON.stringify(places.filter(p => p.id !== 'start').map(p => ({
      id: p.id,
      name: p.name,
      rating: p.rating,
      types: p.types,
      coords: p.coordinates,
      // Fix: Use openingHoursRaw property from Place interface instead of non-existent openingHours
      hours: p.openingHoursRaw || "Nie określono"
    })))}

    PREFERENCJE:
    - Tryb transportu: ${preferences.travelMode}
    - Czas startu: ${preferences.startTime}
    - Dostępny budżet czasowy: ${preferences.availableHours}h
    - Zainteresowania: ${preferences.interests.join(", ")}

    WYMAGANIA DOTYCZĄCE PLANU (W JĘZYKU POLSKIM):
    1. Trasa MUSI zaczynać się w punkcie startowym o godzinie ${preferences.startTime}.
    2. Ustal logiczną kolejność zwiedzania na podstawie współrzędnych geograficznych (minimalizacja dojazdów).
    3. Dla każdego miejsca określ czas wizyty (np. muzeum 90min, park 45min).
    4. Uwzględnij szacowany czas dojazdu między punktami dla trybu ${preferences.travelMode}.
    5. Cały plan musi zmieścić się w ${preferences.availableHours} godzinach.
    6. Zwróć opisowy przewodnik (narrative) zachęcający do wycieczki.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          itinerary: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                placeId: { type: Type.STRING },
                placeName: { type: Type.STRING },
                startTime: { type: Type.STRING },
                endTime: { type: Type.STRING },
                visitDurationMinutes: { type: Type.NUMBER },
                travelTimeFromPreviousMinutes: { type: Type.NUMBER },
                activityDescription: { type: Type.STRING }
              },
              required: ["placeId", "placeName", "startTime", "endTime", "visitDurationMinutes", "travelTimeFromPreviousMinutes", "activityDescription"]
            }
          },
          narrative: { type: Type.STRING },
          tips: { type: Type.ARRAY, items: { type: Type.STRING } },
          alternatives: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                reason: { type: Type.STRING }
              }
            }
          }
        },
        required: ["itinerary", "narrative", "tips", "alternatives"]
      }
    }
  });

  // Fix: Safe access to response text property as per guidelines (string | undefined)
  const text = response.text;
  if (!text) {
    throw new Error("Generowanie planu nie powiodło się - brak odpowiedzi od modelu.");
  }

  return JSON.parse(text.trim());
};
