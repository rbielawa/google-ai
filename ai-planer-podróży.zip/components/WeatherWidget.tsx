
import React, { useEffect, useState } from 'react';
import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun, Sun } from 'lucide-react';
import { fetchCurrentWeather } from '../services/weatherService';
import { Coordinates, WeatherData } from '../types';

interface WeatherWidgetProps {
  coordinates: Coordinates;
  locationName: string;
}

const iconMap: Record<string, any> = {
  Sun,
  CloudSun,
  Cloud,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudSnow,
  CloudLightning
};

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ coordinates, locationName }) => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadWeather = async () => {
      setLoading(true);
      try {
        const data = await fetchCurrentWeather(coordinates);
        setWeather(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadWeather();
  }, [coordinates]);

  if (loading) {
    return (
      <div className="bg-white/50 backdrop-blur-md border border-slate-200 p-4 rounded-[2rem] animate-pulse flex items-center justify-center h-24">
        <div className="w-3 h-3 bg-indigo-200 rounded-full animate-bounce" />
      </div>
    );
  }

  if (!weather) return null;

  const WeatherIcon = iconMap[weather.icon] || Cloud;

  return (
    <div className="bg-gradient-to-br from-indigo-500 to-violet-600 p-4 rounded-[2rem] shadow-lg shadow-indigo-100 text-white relative overflow-hidden group min-h-[120px] flex flex-col justify-center">
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-1">
          <div className="flex flex-col">
            <span className="text-[8px] font-black uppercase tracking-widest opacity-70">Pogoda</span>
            <span className="text-[11px] font-bold truncate max-w-[80px] leading-tight">
              {locationName.split(',')[0]}
            </span>
          </div>
          <div className="bg-white/20 p-1.5 rounded-xl backdrop-blur-sm group-hover:scale-110 transition-transform duration-500">
            <WeatherIcon className="w-5 h-5 text-white" />
          </div>
        </div>
        
        <div className="flex items-baseline gap-1 mt-1">
          <span className="text-2xl font-black">{weather.temp}°C</span>
        </div>
        
        <div className="mt-1">
          <span className="text-[10px] font-medium leading-none opacity-90 block">
            {weather.description}
          </span>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -right-2 -bottom-2 opacity-10">
        <WeatherIcon className="w-16 h-16" />
      </div>
    </div>
  );
};
