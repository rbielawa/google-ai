
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Search, Plus, X, MapPin, Star, Navigation, Building2, Map as MapIcon, 
  Loader2, Utensils, Info, ExternalLink, Banknote, Check, Phone, Clock, 
  Sparkles, Globe, ShieldCheck, Heart, ArrowRight, RefreshCw, CreditCard,
  Ticket, CalendarDays, Zap, ArrowUpDown, AlertCircle
} from 'lucide-react';
import { Place, StartLocation, UserPreferences } from '../types';
import { searchTowns, searchPlacesInTown, getAddressFromCoords } from '../services/mapsService';

interface PlaceSelectorProps {
  startLocation: StartLocation;
  onSetStart: (loc: StartLocation) => void;
  selectedPlaces: Place[];
  onAddPlace: (place: Place) => void;
  onRemovePlace: (id: string) => void;
  preferences: UserPreferences;
}

type SortOption = 'rating' | 'distance' | 'none';

export const PlaceSelector: React.FC<PlaceSelectorProps> = ({ 
  startLocation,
  onSetStart,
  selectedPlaces, 
  onAddPlace, 
  onRemovePlace,
  preferences
}) => {
  const [townQuery, setTownQuery] = useState('');
  const [towns, setTowns] = useState<string[]>([]);
  const [selectedTown, setSelectedTown] = useState<string | null>(null);
  const [placeResults, setPlaceResults] = useState<Place[]>([]);
  const [isSearchingTowns, setIsSearchingTowns] = useState(false);
  const [isSearchingPlaces, setIsSearchingPlaces] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [hoveredPlaceId, setHoveredPlaceId] = useState<string | null>(null);
  const [hoveredRect, setHoveredRect] = useState<DOMRect | null>(null);
  const [sortBy, setSortBy] = useState<SortOption>('none');
  
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setTowns([]);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  };

  const sortedResults = useMemo(() => {
    const results = [...placeResults];
    if (sortBy === 'rating') return results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    if (sortBy === 'distance') {
      return results.sort((a, b) => {
        const distA = calculateDistance(startLocation.coordinates.lat, startLocation.coordinates.lng, a.coordinates.lat, a.coordinates.lng);
        const distB = calculateDistance(startLocation.coordinates.lat, startLocation.coordinates.lng, b.coordinates.lat, b.coordinates.lng);
        return distA - distB;
      });
    }
    return results;
  }, [placeResults, sortBy, startLocation.coordinates]);

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude } = pos.coords;
      const name = await getAddressFromCoords(latitude, longitude);
      onSetStart({ name, coordinates: { lat: latitude, lng: longitude } });
    });
  };

  const handleTownSearch = async (val: string) => {
    setTownQuery(val);
    if (val.length > 2) {
      setIsSearchingTowns(true);
      try {
        const results = await searchTowns(val);
        setTowns(results);
      } finally {
        setIsSearchingTowns(false);
      }
    } else {
      setTowns([]);
    }
  };

  const findPlaces = useCallback(async (townName: string) => {
    setIsSearchingPlaces(true);
    setSearchError(null);
    try {
      const results = await searchPlacesInTown(preferences.interests, townName);
      if (results.length === 0) {
        setSearchError("Nie znaleźliśmy nic w tej okolicy pasującego do wybranych zainteresowań.");
        setPlaceResults([]);
      } else {
        setPlaceResults(results);
      }
    } catch (error) {
      setSearchError("Wystąpił problem z pobieraniem propozycji. Serwer map może być przeciążony.");
      setPlaceResults([]);
      console.error("OSM Search error:", error);
    } finally {
      setIsSearchingPlaces(false);
    }
  }, [preferences.interests]);

  useEffect(() => {
    if (selectedTown) {
      findPlaces(selectedTown);
    }
  }, [preferences.interests, selectedTown, findPlaces]);

  const selectTown = (t: string) => {
    setSelectedTown(t);
    setTownQuery(t.split(',')[0]);
    setTowns([]);
  };

  const renderStars = (rating: number = 0, size: "sm" | "md" = "sm") => (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star key={star} className={`${size === "sm" ? "w-3 h-3" : "w-4 h-4"} ${star <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'}`} />
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2 text-slate-800">
          <Navigation className="w-5 h-5 text-indigo-600" />
          1. Skąd ruszasz?
        </h2>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <input type="text" readOnly value={startLocation.name} className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm outline-none" />
            <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          </div>
          <button onClick={handleUseMyLocation} className="px-5 py-3 bg-indigo-50 text-indigo-600 rounded-2xl text-sm font-bold hover:bg-indigo-100 transition-all flex items-center gap-2 border border-indigo-100">
            <Navigation className="w-4 h-4" /> GPS
          </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200" ref={dropdownRef}>
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2 text-slate-800">
          <Building2 className="w-5 h-5 text-indigo-600" />
          2. Gdzie chcesz jechać?
        </h2>
        
        {!selectedTown ? (
          <div className="relative">
            <input type="text" value={townQuery} onChange={(e) => handleTownSearch(e.target.value)} placeholder="Wpisz nazwę miasta..." className="w-full pl-10 pr-12 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition-all" />
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            {isSearchingTowns && <Loader2 className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-500 animate-spin" />}
            {towns.length > 0 && (
              <div className="absolute z-[100] top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden">
                {towns.map((t, idx) => (
                  <button key={idx} onClick={() => selectTown(t)} className="w-full text-left px-5 py-3.5 text-sm hover:bg-indigo-50 border-b border-slate-50 last:border-0 transition-colors flex items-center justify-between group">
                    <span className="truncate font-medium">{t}</span>
                    <Check className="w-4 h-4 text-indigo-500 opacity-0 group-hover:opacity-100" />
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-100 rounded-2xl group">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white rounded-xl shadow-sm"><MapIcon className="w-5 h-5 text-indigo-600" /></div>
              <div>
                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Wybrane miasto</p>
                <p className="text-sm font-bold text-slate-800">{selectedTown.split(',')[0]}</p>
              </div>
            </div>
            <button onClick={() => { setSelectedTown(null); setTownQuery(''); setPlaceResults([]); setSearchError(null); }} className="p-2 text-slate-400 hover:text-red-500 rounded-xl"><X className="w-5 h-5" /></button>
          </div>
        )}
      </div>

      {(placeResults.length > 0 || isSearchingPlaces || searchError) && (
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
          <div className="flex flex-col gap-4 mb-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Propozycje {preferences.interests.length > 0 && `dla: ${preferences.interests.join(', ')}`}</h3>
              {isSearchingPlaces && <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />}
            </div>

            {searchError && !isSearchingPlaces && (
              <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-100 rounded-2xl text-amber-800 text-sm animate-in fade-in duration-300">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <p className="font-medium">{searchError}</p>
              </div>
            )}

            {!isSearchingPlaces && placeResults.length > 0 && (
              <div className="flex items-center gap-2 p-1 bg-slate-50 rounded-xl border border-slate-100">
                <button onClick={() => setSortBy('rating')} className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-bold transition-all ${sortBy === 'rating' ? 'bg-white text-indigo-600 shadow-sm border border-indigo-100' : 'text-slate-500'}`}>Najlepsze</button>
                <button onClick={() => setSortBy('distance')} className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-bold transition-all ${sortBy === 'distance' ? 'bg-white text-indigo-600 shadow-sm border border-indigo-100' : 'text-slate-500'}`}>Najbliższe</button>
              </div>
            )}
          </div>
          
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
            {isSearchingPlaces ? (
              <div className="py-20 flex flex-col items-center justify-center text-slate-400 gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
                <p className="text-sm font-medium">Szukamy najlepszych miejsc...</p>
              </div>
            ) : sortedResults.map((place, idx) => {
              const distance = calculateDistance(startLocation.coordinates.lat, startLocation.coordinates.lng, place.coordinates.lat, place.coordinates.lng);
              return (
                <div 
                  key={place.id} 
                  className="relative flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-indigo-300 hover:bg-white transition-all group animate-in fade-in duration-300" 
                  onMouseEnter={(e) => { setHoveredPlaceId(place.id); setHoveredRect(e.currentTarget.getBoundingClientRect()); }} 
                  onMouseLeave={(e) => {
                    const relatedTarget = e.relatedTarget as HTMLElement;
                    if (relatedTarget && (relatedTarget.closest('.rich-popup') || relatedTarget.closest('.bridge-zone'))) return;
                    setHoveredPlaceId(null); 
                    setHoveredRect(null); 
                  }}
                >
                  <div className="flex-1 min-w-0 pr-4">
                    <h3 className="text-sm font-bold truncate text-slate-800">{place.name}</h3>
                    <div className="mt-1 flex items-center gap-2">
                      {renderStars(place.rating)}
                      <span className="text-[9px] text-indigo-400 font-black">{distance.toFixed(1)} km</span>
                    </div>
                  </div>
                  <button onClick={() => onAddPlace(place)} disabled={selectedPlaces.some(p => p.id === place.id)} className="p-2.5 bg-white text-indigo-600 rounded-xl border border-indigo-100 hover:bg-indigo-600 hover:text-white transition-all shadow-sm disabled:opacity-30">
                    <Plus className="w-5 h-5" />
                  </button>

                  {hoveredPlaceId === place.id && hoveredRect && (
                    <>
                      {/* Bridge to prevent closing when moving mouse to popup */}
                      <div className="bridge-zone fixed z-[998]" style={{ left: `${hoveredRect.right}px`, top: `${hoveredRect.top}px`, width: '40px', height: `${hoveredRect.height}px` }} />
                      
                      <div 
                        className="rich-popup fixed z-[999] w-[380px] md:w-[460px] bg-white rounded-[2rem] shadow-[0_30px_100px_rgba(0,0,0,0.15)] border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-left-4 pointer-events-auto" 
                        style={{ 
                          left: `${hoveredRect.right + 24}px`, 
                          top: `${Math.min(window.innerHeight - 620, Math.max(20, hoveredRect.top - 40))}px` 
                        }}
                        onMouseLeave={() => { setHoveredPlaceId(null); setHoveredRect(null); }}
                      >
                        {/* Photo Header */}
                        <div className="relative h-48 w-full">
                          <img 
                            src={place.photos?.[0] || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80'} 
                            alt={place.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                          <div className="absolute bottom-4 left-6 right-6">
                            <span className="px-3 py-1 bg-indigo-600 text-white text-[9px] font-black uppercase tracking-widest rounded-full mb-2 inline-block shadow-lg">
                              {place.types[0] || 'Atrakcja'}
                            </span>
                            <h4 className="text-xl font-black text-white leading-tight drop-shadow-md">{place.name}</h4>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="p-6 space-y-4">
                          {/* Rating & Distance */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {renderStars(place.rating, "md")}
                              <span className="text-sm font-bold text-slate-400">({place.rating?.toFixed(1)})</span>
                            </div>
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-50 border border-slate-100 rounded-full">
                               <Navigation className="w-3 h-3 text-indigo-500" />
                               <span className="text-[10px] font-black text-slate-500">{distance.toFixed(1)} km stąd</span>
                            </div>
                          </div>

                          {/* Description */}
                          <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                            <p className="text-sm text-slate-600 leading-relaxed line-clamp-4 italic">
                              "{place.description || 'Miejsce o wyjątkowej atmosferze, które warto uwzględnić w swoim planie zwiedzania.'}"
                            </p>
                          </div>

                          {/* Highlights */}
                          <div className="flex flex-wrap gap-2">
                            {place.highlights?.slice(0, 4).map((h, i) => (
                              <span key={i} className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                                {h}
                              </span>
                            ))}
                          </div>

                          {/* Info Grid */}
                          <div className="grid grid-cols-2 gap-3 pt-2">
                            <div className="p-3 bg-white border border-slate-100 rounded-xl flex flex-col justify-center">
                              <div className="text-[9px] font-black text-slate-400 uppercase mb-1 tracking-wider">Ceny i Wstęp</div>
                              <div className="text-xs font-bold text-indigo-600 flex items-center gap-1.5">
                                <Banknote className="w-3.5 h-3.5" />
                                <span className="truncate">{place.feeInfo || 'Brak danych'}</span>
                              </div>
                            </div>
                            <div className="p-3 bg-white border border-slate-100 rounded-xl flex flex-col justify-center">
                              <div className="text-[9px] font-black text-slate-400 uppercase mb-1 tracking-wider">Dostępność</div>
                              <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 text-slate-400" />
                                <span className="truncate">{place.openingHoursRaw?.includes('Brak') ? 'Na zapytanie' : 'Standard'}</span>
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="pt-4 flex gap-3">
                            {place.website && (
                              <a 
                                href={place.website} 
                                target="_blank" 
                                className="flex-1 flex items-center justify-center gap-2 py-3 bg-white border-2 border-slate-100 rounded-xl text-xs font-black text-slate-600 hover:border-indigo-600 hover:text-indigo-600 transition-all"
                              >
                                <ExternalLink className="w-4 h-4" /> WWW
                              </a>
                            )}
                            <button 
                              onClick={() => onAddPlace(place)} 
                              disabled={selectedPlaces.some(p => p.id === place.id)}
                              className="flex-[2] py-3 bg-indigo-600 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:bg-slate-200 disabled:shadow-none"
                            >
                              Dodaj do planu dnia
                            </button>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {selectedPlaces.length > 0 && (
        <div className="bg-slate-900 p-6 rounded-3xl shadow-2xl border border-slate-800">
          <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em] mb-4">Wybrane punkty ({selectedPlaces.length})</h3>
          <div className="space-y-2">
            {selectedPlaces.map(place => (
              <div key={place.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-xl border border-slate-700/50 group">
                <span className="text-sm font-bold text-white truncate pr-4">{place.name}</span>
                <button onClick={() => onRemovePlace(place.id)} className="text-slate-500 hover:text-red-400 transition-colors"><X className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
