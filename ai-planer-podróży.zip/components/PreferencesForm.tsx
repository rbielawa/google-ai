
import React from 'react';
import { Clock, Sliders, Car, Footprints, Bus, Timer } from 'lucide-react';
import { UserPreferences } from '../types';

interface PreferencesFormProps {
  preferences: UserPreferences;
  onChange: (prefs: UserPreferences) => void;
  onSubmit: () => void;
  isLoading: boolean;
  disabled: boolean;
}

export const PreferencesForm: React.FC<PreferencesFormProps> = ({ 
  preferences, 
  onChange, 
  onSubmit, 
  isLoading,
  disabled 
}) => {
  const toggleInterest = (interest: string) => {
    const newInterests = preferences.interests.includes(interest)
      ? preferences.interests.filter(i => i !== interest)
      : [...preferences.interests, interest];
    onChange({ ...preferences, interests: newInterests });
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
      <h2 className="text-lg font-semibold flex items-center gap-2">
        <Sliders className="w-5 h-5 text-indigo-500" />
        Preferencje
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <label className="block text-sm font-medium text-slate-700">Co Cię interesuje?</label>
          <div className="flex flex-wrap gap-2">
            {['Historia', 'Muzea', 'Zamki', 'Natura', 'Sztuka', 'Jedzenie', 'Architektura', 'Nauka'].map(interest => (
              <button
                key={interest}
                type="button"
                onClick={() => toggleInterest(interest)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  preferences.interests.includes(interest)
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
                <Clock className="w-4 h-4 text-slate-400" /> Start
              </label>
              <input
                type="time"
                value={preferences.startTime}
                onChange={(e) => onChange({ ...preferences, startTime: e.target.value })}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-[44px]"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
                <Timer className="w-4 h-4 text-slate-400" /> Czas (h)
              </label>
              <input
                type="number"
                min="1"
                max="24"
                value={preferences.availableHours}
                onChange={(e) => onChange({ ...preferences, availableHours: parseInt(e.target.value) || 1 })}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-[44px]"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Środek transportu</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'DRIVING', icon: Car, label: 'Auto' },
                { id: 'WALKING', icon: Footprints, label: 'Pieszo' },
                { id: 'TRANSIT', icon: Bus, label: 'ZTM' },
              ].map(mode => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => onChange({ ...preferences, travelMode: mode.id as any })}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${
                    preferences.travelMode === mode.id
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 ring-1 ring-indigo-600'
                      : 'border-slate-200 bg-slate-50 text-slate-500 hover:border-indigo-300'
                  }`}
                >
                  <mode.icon className="w-5 h-5 mb-1" />
                  <span className="text-[10px] font-bold uppercase">{mode.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={onSubmit}
        disabled={disabled || isLoading}
        className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:shadow-none disabled:bg-slate-400 transition-all flex items-center justify-center gap-2"
      >
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Generowanie planu...
          </>
        ) : (
          'Generuj zoptymalizowany plan'
        )}
      </button>
    </div>
  );
};
