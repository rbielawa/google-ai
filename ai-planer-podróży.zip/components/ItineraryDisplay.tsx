
import React, { useState } from 'react';
import { Calendar, Navigation, Info, AlertTriangle, Lightbulb, RefreshCw, Mail, FileText, Send, CheckCircle2, Loader2, X } from 'lucide-react';
import { DayPlan } from '../types';

interface ItineraryDisplayProps {
  plan: DayPlan;
  onReset: () => void;
}

export const ItineraryDisplay: React.FC<ItineraryDisplayProps> = ({ plan, onReset }) => {
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendStep, setSendStep] = useState<'idle' | 'pdf' | 'sending' | 'success'>('idle');

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setSendStep('pdf');
    setIsSending(true);

    // Symulacja procesu
    setTimeout(() => {
      setSendStep('sending');
      setTimeout(() => {
        setSendStep('success');
        setIsSending(false);
        setTimeout(() => {
          setShowEmailForm(false);
          setSendStep('idle');
          setEmail('');
        }, 3000);
      }, 2000);
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700 slide-in-from-bottom-4">
      {/* Narrative Section */}
      <div className="bg-indigo-600 text-white p-8 rounded-3xl shadow-xl shadow-indigo-100 overflow-hidden relative">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Lightbulb className="w-6 h-6" /> Twój Przewodnik AI
            </h2>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowEmailForm(true)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors backdrop-blur-md"
                title="Wyślij PDF"
              >
                <Mail className="w-5 h-5" />
              </button>
              <button 
                onClick={onReset}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors backdrop-blur-md"
                title="Nowy plan"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>
          <p className="text-indigo-100 leading-relaxed italic">
            "{plan.narrative}"
          </p>
        </div>
        <div className="absolute -right-8 -bottom-8 opacity-10">
            <Calendar className="w-48 h-48" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Timeline */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-lg font-bold flex items-center gap-2 px-2 text-slate-800">
            <Calendar className="w-5 h-5 text-indigo-500" /> 
            Harmonogram dnia
          </h3>
          <div className="space-y-4">
            {plan.itinerary.map((item, idx) => (
              <div key={idx} className="relative pl-8">
                {idx !== plan.itinerary.length - 1 && (
                  <div className="absolute left-[11px] top-6 bottom-0 w-0.5 bg-slate-200" />
                )}
                <div className="absolute left-0 top-1.5 w-[24px] h-[24px] rounded-full bg-white border-4 border-indigo-600 z-10 shadow-sm" />

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-4">
                    <h4 className="font-bold text-lg text-slate-800">{item.placeName}</h4>
                    <span className="text-sm font-bold px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full">
                      {item.startTime} - {item.endTime}
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-4 text-sm text-slate-500 mb-4 pb-4 border-b border-slate-100">
                    <span className="flex items-center gap-1 font-medium">
                      <ClockIcon className="w-4 h-4" /> Wizyta: {item.visitDurationMinutes} min
                    </span>
                    {item.travelTimeFromPreviousMinutes > 0 && (
                      <span className="flex items-center gap-1 font-medium text-orange-600">
                        <Navigation className="w-4 h-4" /> Dojazd: {item.travelTimeFromPreviousMinutes} min
                      </span>
                    )}
                  </div>
                  
                  <p className="text-slate-600 leading-relaxed text-sm">
                    {item.activityDescription}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom Actions */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button 
              onClick={() => setShowEmailForm(true)}
              className="flex-1 py-4 px-6 bg-indigo-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-[0.98]"
            >
              <FileText className="w-5 h-5" /> Wyślij plan na e-mail (PDF)
            </button>
            <button 
              onClick={onReset}
              className="flex-1 py-4 px-6 bg-white text-slate-600 border border-slate-200 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-50 transition-all active:scale-[0.98]"
            >
              <RefreshCw className="w-5 h-5" /> Generuj nowy plan
            </button>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Info className="w-4 h-4" /> Wskazówki
            </h3>
            <ul className="space-y-4">
              {plan.tips.map((tip, idx) => (
                <li key={idx} className="text-sm text-slate-600 flex gap-3">
                  <span className="text-indigo-600 font-bold">•</span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-orange-50 p-6 rounded-2xl border border-orange-100 shadow-sm">
            <h3 className="text-sm font-bold text-orange-700 uppercase tracking-widest mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> Alternatywy
            </h3>
            <div className="space-y-4">
              {plan.alternatives.map((alt, idx) => (
                <div key={idx}>
                  <p className="text-sm font-bold text-slate-800">{alt.name}</p>
                  <p className="text-xs text-slate-500 mt-1 leading-snug">{alt.reason}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Email Modal / Overlay */}
      {showEmailForm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden relative animate-in zoom-in-95 duration-300">
            <button 
              onClick={() => !isSending && setShowEmailForm(false)}
              className="absolute right-4 top-4 p-2 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            
            <div className="p-8">
              <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                <Mail className="w-8 h-8 text-indigo-600" />
              </div>

              {sendStep === 'idle' ? (
                <>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Wyślij plan</h3>
                  <p className="text-slate-500 mb-6">Wpisz swój adres e-mail, aby otrzymać trasę w formacie PDF gotowym do druku.</p>
                  
                  <form onSubmit={handleSendEmail} className="space-y-4">
                    <div className="relative">
                      <input 
                        type="email" 
                        required
                        placeholder="twoj@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
                      />
                    </div>
                    <button 
                      type="submit"
                      className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 flex items-center justify-center gap-2 transition-all"
                    >
                      <Send className="w-5 h-5" /> Wyślij teraz
                    </button>
                  </form>
                </>
              ) : (
                <div className="py-8 text-center space-y-4">
                  {sendStep === 'pdf' && (
                    <>
                      <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto" />
                      <p className="text-lg font-bold text-slate-800">Generowanie PDF...</p>
                      <p className="text-sm text-slate-400">Składamy Twoje zdjęcia i mapy w jeden dokument.</p>
                    </>
                  )}
                  {sendStep === 'sending' && (
                    <>
                      <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto" />
                      <p className="text-lg font-bold text-slate-800">Wysyłanie e-maila...</p>
                      <p className="text-sm text-slate-400">Poczekaj chwilkę, plik jest już w drodze.</p>
                    </>
                  )}
                  {sendStep === 'success' && (
                    <div className="animate-in zoom-in duration-500">
                      <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                      <p className="text-xl font-bold text-slate-800">Gotowe!</p>
                      <p className="text-sm text-slate-500">Twój plan podróży został wysłany na adres:<br/><span className="font-bold text-slate-700">{email}</span></p>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="bg-slate-50 px-8 py-4 text-center">
              <p className="text-[10px] uppercase font-black tracking-widest text-slate-400">Smart Planer AI &bull; PDF Service</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ClockIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
