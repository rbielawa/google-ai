
import React, { useEffect, useRef } from 'react';
import { Place, ItineraryItem, StartLocation } from '../types';
import L from 'leaflet';

interface MapComponentProps {
  startLocation: StartLocation;
  places: Place[];
  itinerary?: ItineraryItem[];
}

export const MapComponent: React.FC<MapComponentProps> = ({ startLocation, places, itinerary }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);

  useEffect(() => {
    if (mapContainerRef.current && !mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapContainerRef.current, {
        scrollWheelZoom: true,
        zoomControl: true
      }).setView([startLocation.coordinates.lat, startLocation.coordinates.lng], 12);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(mapInstanceRef.current);

      markersRef.current = L.layerGroup().addTo(mapInstanceRef.current);
    }

    const handleResize = () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const createStarsHtml = (rating: number = 0) => {
    const fullStars = Math.round(rating);
    let stars = '';
    for (let i = 1; i <= 5; i++) {
      stars += `<span style="color: ${i <= fullStars ? '#fbbf24' : '#e2e8f0'}">★</span>`;
    }
    return `<div style="display: flex; align-items: center; gap: 4px; margin-bottom: 8px;">
              <div style="font-size: 16px; letter-spacing: 1px;">${stars}</div>
              <span style="font-size: 12px; color: #1e293b; font-weight: 800;">${rating.toFixed(1)}</span>
            </div>`;
  };

  const createRichPopupHtml = (place: Place, itineraryItem?: ItineraryItem, index?: number) => {
    const highlightsHtml = place.highlights?.map(h => 
      `<span style="display: inline-block; background: #e0e7ff; color: #4338ca; font-size: 10px; padding: 4px 10px; border-radius: 99px; margin-right: 6px; margin-bottom: 6px; font-weight: 700; border: 1px solid #c7d2fe;">${h}</span>`
    ).join('') || '';

    const googleSearchUrl = `https://www.google.com/search?q=${encodeURIComponent(place.name + ' ' + place.address)}`;
    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${place.coordinates.lat},${place.coordinates.lng}`;

    // Generowanie galerii zdjęć
    const photoGallery = place.photos && place.photos.length > 0 ? `
      <div style="margin: 12px 0; overflow: hidden; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
        <div style="display: flex; gap: 4px; overflow-x: auto; padding-bottom: 4px;" class="custom-scrollbar">
          ${place.photos.map(url => `
            <a href="${url}" target="_blank" style="flex: 0 0 140px; height: 90px; border-radius: 12px; overflow: hidden; transition: transform 0.2s;">
              <img src="${url}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" />
            </a>
          `).join('')}
        </div>
        <div style="text-align: center; font-size: 9px; color: #94a3b8; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px;">Kliknij zdjęcie, aby powiększyć</div>
      </div>
    ` : '';

    const infoLinks = `
      <div style="margin-top: 16px; padding-top: 16px; border-top: 1px dashed #e2e8f0;">
        <div style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; margin-bottom: 10px; letter-spacing: 0.5px;">Baza Wiedzy i Multimedia:</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <a href="${googleSearchUrl}" target="_blank" style="text-decoration: none; display: flex; align-items: center; gap: 6px; padding: 8px; background: #f1f5f9; border-radius: 10px; color: #334155; font-size: 10px; font-weight: 700; transition: background 0.2s;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> Szukaj w Google
          </a>
          <a href="${googleMapsUrl}" target="_blank" style="text-decoration: none; display: flex; align-items: center; gap: 6px; padding: 8px; background: #fef2f2; border-radius: 10px; color: #991b1b; font-size: 10px; font-weight: 700; transition: background 0.2s;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> Opinie i Foto
          </a>
        </div>
      </div>
    `;

    return `
      <div style="min-width: 320px; max-width: 360px; padding: 6px; font-family: 'Inter', sans-serif;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
          <div style="display: flex; flex-direction: column; gap: 4px;">
            <span style="background: #eff6ff; color: #1d4ed8; font-size: 9px; font-weight: 900; padding: 3px 10px; border-radius: 99px; text-transform: uppercase; letter-spacing: 0.8px; border: 1px solid #dbeafe;">
              ${place.types[0] || 'Atrakcja'}
            </span>
          </div>
          ${index !== undefined ? `<div style="background: #4f46e5; color: white; width: 34px; height: 34px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 18px; box-shadow: 0 4px 10px rgba(79, 70, 229, 0.4);">#${index + 1}</div>` : ''}
        </div>
        
        <h3 style="margin: 0 0 6px 0; font-size: 20px; font-weight: 900; color: #0f172a; line-height: 1.1; letter-spacing: -0.03em;">${place.name}</h3>
        ${createStarsHtml(place.rating)}
        
        ${photoGallery}

        <div style="background: #fdf2f8; color: #be185d; font-size: 11px; font-weight: 700; padding: 8px 12px; border-radius: 10px; display: inline-flex; align-items: center; gap: 8px; margin-bottom: 14px; border: 1px solid #fce7f3; width: calc(100% - 24px);">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          ${place.address}
        </div>

        <div style="font-size: 14px; color: #334155; line-height: 1.6; margin-bottom: 18px; font-weight: 400; padding: 0 4px;">
          ${place.description || 'Odkryj uroki tego miejsca podczas swojej wycieczki.'}
        </div>

        ${itineraryItem ? `
          <div style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); border-radius: 16px; padding: 14px; margin: 16px 0; color: white; box-shadow: 0 12px 20px -5px rgba(79, 70, 229, 0.3);">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.25); padding-bottom: 8px;">
              <span style="font-size: 11px; font-weight: 800; text-transform: uppercase; opacity: 0.9; letter-spacing: 0.5px;">Twój Plan:</span>
              <span style="font-size: 14px; font-weight: 900; letter-spacing: 0.5px;">${itineraryItem.startTime} - ${itineraryItem.endTime}</span>
            </div>
            <div style="font-size: 12px; font-weight: 500; line-height: 1.5; color: rgba(255,255,255,0.95);">
              <strong style="display: block; margin-bottom: 6px; text-transform: uppercase; font-size: 10px; letter-spacing: 1px; color: #fff;">Inspiracja od Gemini:</strong>
              ${itineraryItem.activityDescription}
            </div>
          </div>
        ` : ''}

        <div style="display: grid; grid-template-columns: 1fr; gap: 10px; margin-bottom: 16px;">
           <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px;">
             <div style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> Godziny Dostępności
             </div>
             <div style="font-size: 12px; font-weight: 700; color: #1e293b;">${place.openingHoursRaw || 'Sprawdź na miejscu'}</div>
           </div>
        </div>

        <div style="margin-bottom: 16px;">
          <div style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; margin-bottom: 8px; letter-spacing: 0.5px;">Atrybuty:</div>
          <div style="display: flex; flex-wrap: wrap;">
            ${highlightsHtml}
          </div>
        </div>

        ${infoLinks}

        <div style="display: flex; gap: 10px; margin-top: 16px;">
          ${place.phone ? `<a href="tel:${place.phone}" style="flex: 1; text-decoration: none; background: #fff; color: #4f46e5; border: 2px solid #4f46e5; font-size: 12px; font-weight: 800; padding: 12px; border-radius: 14px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg> ZADZWOŃ</a>` : ''}
          ${place.website ? `<a href="${place.website}" target="_blank" style="flex: 1; text-decoration: none; background: #4f46e5; color: white; font-size: 12px; font-weight: 800; padding: 12px; border-radius: 14px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> WWW</a>` : ''}
        </div>
      </div>
    `;
  };

  useEffect(() => {
    if (!mapInstanceRef.current || !markersRef.current) return;

    markersRef.current.clearLayers();
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    const points: L.LatLngExpression[] = [];
    const bounds = L.latLngBounds([]);

    const startPos: L.LatLngExpression = [startLocation.coordinates.lat, startLocation.coordinates.lng];
    const startIcon = L.divIcon({
      className: 'custom-start-icon',
      html: `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-8 h-8 bg-indigo-500 rounded-full animate-ping opacity-20"></div>
          <div style="background-color: #4f46e5; color: white; width: 32px; height: 32px; border-radius: 12px; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 4px 12px rgba(0,0,0,0.2);">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
          </div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    L.marker(startPos, { icon: startIcon })
      .bindPopup(`
        <div style="padding: 16px; font-family: 'Inter', sans-serif; min-width: 220px;">
          <div style="font-size: 11px; font-weight: 900; color: #4f46e5; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">PUNKT WYJŚCIA</div>
          <div style="font-weight: 900; color: #0f172a; font-size: 18px; line-height: 1.2; margin-bottom: 10px;">${startLocation.name}</div>
          <div style="height: 3px; width: 40px; background: #4f46e5; margin-bottom: 10px; border-radius: 99px;"></div>
          <div style="font-size: 13px; color: #64748b; font-weight: 500; line-height: 1.5;">To jest Twoja lokalizacja bazowa.</div>
        </div>
      `)
      .addTo(markersRef.current);
    
    bounds.extend(startPos);
    points.push(startPos);

    if (itinerary && itinerary.length > 0) {
      itinerary.forEach((item, index) => {
        const place = places.find(p => p.id === item.placeId);
        if (place) {
          const pos: L.LatLngExpression = [place.coordinates.lat, place.coordinates.lng];
          points.push(pos);
          
          const icon = L.divIcon({
            className: 'custom-div-icon',
            html: `<div style="background-color: #4f46e5; color: white; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 900; border: 4px solid white; box-shadow: 0 6px 15px rgba(79, 70, 229, 0.4); font-size: 16px;">${index + 1}</div>`,
            iconSize: [36, 36],
            iconAnchor: [18, 18]
          });

          L.marker(pos, { icon })
            .bindPopup(createRichPopupHtml(place, item, index), { maxWidth: 380 })
            .addTo(markersRef.current!);
          
          bounds.extend(pos);
        }
      });

      if (points.length > 1) {
        polylineRef.current = L.polyline(points, { 
          color: '#4f46e5', 
          weight: 6, 
          opacity: 0.65, 
          dashArray: '12, 18',
          lineCap: 'round'
        }).addTo(mapInstanceRef.current);
      }
    } else {
      places.forEach(place => {
        const pos: L.LatLngExpression = [place.coordinates.lat, place.coordinates.lng];
        L.marker(pos)
          .bindPopup(createRichPopupHtml(place), { maxWidth: 380 })
          .addTo(markersRef.current!);
        bounds.extend(pos);
      });
    }

    if (bounds.isValid()) {
      mapInstanceRef.current.fitBounds(bounds, { 
        padding: [70, 70], 
        animate: true,
        duration: 1.8
      });
    }
  }, [startLocation, places, itinerary]);

  return (
    <div className="w-full h-full min-h-[350px] z-0 relative">
      <div ref={mapContainerRef} className="w-full h-full" />
      <style dangerouslySetInnerHTML={{ __html: `
        .leaflet-popup-content-wrapper {
          border-radius: 32px !important;
          padding: 12px !important;
          box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.2) !important;
          border: 1px solid #f1f5f9 !important;
        }
        .leaflet-popup-tip {
          background: white !important;
        }
        .leaflet-popup-close-button {
          top: 16px !important;
          right: 16px !important;
          color: #94a3b8 !important;
          font-size: 24px !important;
          font-weight: bold !important;
        }
        .leaflet-popup-content {
          margin: 12px 16px !important;
        }
        .custom-scrollbar::-webkit-scrollbar {
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
        }
      `}} />
    </div>
  );
};
