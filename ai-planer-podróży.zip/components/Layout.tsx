
import React from 'react';
import { Compass, Map as MapIcon, Calendar, Info } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">
              AI Planer Podróży
            </h1>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#" className="flex items-center gap-1 hover:text-indigo-600 transition-colors">
              <Calendar className="w-4 h-4" /> Planer
            </a>
            <a href="#" className="flex items-center gap-1 hover:text-indigo-600 transition-colors">
              <MapIcon className="w-4 h-4" /> Mapa
            </a>
            <a href="#" className="flex items-center gap-1 hover:text-indigo-600 transition-colors">
              <Info className="w-4 h-4" /> O nas
            </a>
          </nav>
        </div>
      </header>
      <main className="flex-1 max-w-6xl mx-auto w-full p-4 md:p-8">
        {children}
      </main>
      <footer className="bg-white border-t border-slate-200 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-slate-500">
          &copy; 2024 AI Planer Podróży. Napędzane przez Gemini i Google Maps.
        </div>
      </footer>
    </div>
  );
};
