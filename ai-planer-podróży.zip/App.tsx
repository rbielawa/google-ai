
import React, { useState, useEffect } from 'react';
import { Map as MapIcon } from 'lucide-react';
import { Layout } from './components/Layout';
import { PlaceSelector } from './components/PlaceSelector';
import { PreferencesForm } from './components/PreferencesForm';
import { ItineraryDisplay } from './components/ItineraryDisplay';
import { MapComponent } from './components/MapComponent';
import { WeatherWidget } from './components/WeatherWidget';
import { Place, DayPlan, UserPreferences, StartLocation } from './types';
import { generateDayPlan } from './services/geminiService';

const App: React.FC = () => {
  const [startLocation, setStartLocation] = useState<StartLocation>({
    name: 'Warszawa, Centrum',
    coordinates: { lat: 52.2297, lng: 21.0122 }
  });
  
  const [selectedPlaces, setSelectedPlaces] = useState<Place[]>([]);
  const [preferences, setPreferences] = useState<UserPreferences>({
    interests: ['Historia', 'Sztuka'],
    availableHours: 8,
    startTime: '09:00',
    travelMode: 'DRIVING',
    startLocation: startLocation // Initial sync
  });

  const [plan, setPlan] = useState<DayPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setPreferences(prev => ({ ...prev, startLocation }));
  }, [startLocation]);

  const handleAddPlace = (place: Place) => {
    if (selectedPlaces.length >= 10) {
      alert("Maksymalnie 10 punktów dla optymalnego planu.");
      return;
    }
    if (selectedPlaces.some(p => p.id === place.id)) return;
    setSelectedPlaces(prev => [...prev, place]);
  };

  const handleRemovePlace = (id: string) => {
    setSelectedPlaces(prev => prev.filter(p => p.id !== id));
  };

  const handleResetPlan = () => {
    setPlan(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGenerate = async () => {
    if (selectedPlaces.length < 1) {
      alert("Wybierz przynajmniej jedno miejsce docelowe.");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const allPoints = [
        { 
          id: 'start', 
          name: `PUNKT STARTOWY: ${startLocation.name}`, 
          coordinates: startLocation.coordinates,
          address: startLocation.name,
          types: ['origin']
        } as Place,
        ...selectedPlaces
      ];

      const generatedPlan = await generateDayPlan(allPoints, [], preferences);
      setPlan(generatedPlan);
      
      setTimeout(() => {
        document.getElementById('itinerary-view')?.scrollIntoView({ behavior: 'smooth' });
      }, 300);
    } catch (err: any) {
      console.error(err);
      setError("Nie udało się wygenerować planu. Spróbuj ponownie za chwilę.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col xl:flex-row gap-8 relative items-start">
        {/* Lewa kolumna - Sticky Sidebar */}
        <div className="w-full xl:w-[42%] xl:sticky xl:top-24 space-y-6">
          <div className="space-y-2">
            <h2 className="text-4xl font-black text-slate-900 tracking-tight leading-none">
              Twój <span className="text-indigo-600">Smart</span> Planer
            </h2>
            <p className="text-slate-500 font-medium text-sm">
              Zacznij od domu, hotelu lub GPS. Wybierz miasta i odkrywaj najlepsze miejsca.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Powiększona mapa: zajmuje 2 z 3 kolumn w siatce poziomej */}
            <div className="md:col-span-2 h-[260px] md:h-[340px] w-full relative z-10 shadow-xl rounded-[2rem] overflow-hidden border border-slate-200 bg-white">
              <MapComponent startLocation={startLocation} places={selectedPlaces} itinerary={plan?.itinerary} />
            </div>
            
            {/* Widgety boczne: zajmują 1 kolumnę */}
            <div className="md:col-span-1 flex flex-col gap-3">
              <WeatherWidget coordinates={startLocation.coordinates} locationName={startLocation.name} />
              <div className="bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col justify-center flex-1">
                <span className="text-[9px] font-black uppercase tracking-widest text-indigo-400 mb-1">Punkty</span>
                <span className="text-2xl font-black text-slate-800">{selectedPlaces.length}</span>
                <p className="text-[10px] text-slate-400 mt-1 leading-tight">Miejsc w Twojej trasie</p>
                <div className="mt-4 pt-4 border-t border-slate-50">
                   <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-indigo-500 h-full transition-all duration-500" 
                        style={{ width: `${Math.min(100, (selectedPlaces.length / 10) * 100)}%` }} 
                      />
                   </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-5">
            <PlaceSelector 
              startLocation={startLocation}
              onSetStart={setStartLocation}
              selectedPlaces={selectedPlaces}
              onAddPlace={handleAddPlace}
              onRemovePlace={handleRemovePlace}
              preferences={preferences}
            />

            <PreferencesForm 
              preferences={preferences}
              onChange={setPreferences}
              onSubmit={handleGenerate}
              isLoading={loading}
              disabled={selectedPlaces.length < 1}
            />
          </div>
          
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm font-bold animate-pulse">
              ⚠️ {error}
            </div>
          )}
        </div>

        {/* Prawa kolumna - Plan Dnia */}
        <div className="w-full xl:w-[58%]" id="itinerary-view">
          {plan ? (
            <ItineraryDisplay plan={plan} onReset={handleResetPlan} />
          ) : (
            <div className="h-full min-h-[600px] flex flex-col items-center justify-center bg-white rounded-[2.5rem] border-2 border-dashed border-slate-200 p-12 text-center">
              <div className="bg-indigo-50 p-6 rounded-3xl mb-6">
                <MapIcon className="w-16 h-16 text-indigo-200" />
              </div>
              <h3 className="text-2xl font-black text-slate-300">Gotowy do drogi?</h3>
              <p className="text-slate-400 text-lg max-w-sm mt-4 leading-relaxed">
                Skonfiguruj trasę po lewej stronie, a we współpracy z Gemini zajmiemy się logistyką.
              </p>
              <div className="mt-8 flex flex-col gap-3 text-slate-400 text-sm">
                <p>• Wybierz miasto w punkcie 2</p>
                <p>• Kliknij "Szukaj", aby zobaczyć atrakcje</p>
                <p>• Dodaj ulubione miejsca do trasy</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default App;
