
export interface Coordinates {
  lat: number;
  lng: number;
}

export interface WeatherData {
  temp: number;
  condition: string;
  icon: string;
  description: string;
}

export interface Place {
  id: string;
  name: string;
  description?: string;
  website?: string;
  phone?: string;
  feeInfo?: string;
  rating?: number;
  openingHoursRaw?: string;
  highlights?: string[];
  address: string;
  coordinates: Coordinates;
  types: string[];
  photos?: string[];
}

export interface StartLocation {
  name: string;
  coordinates: Coordinates;
}

export interface TravelTime {
  originId: string;
  destinationId: string;
  durationSeconds: number;
  distanceMeters: number;
}

export interface ItineraryItem {
  placeId: string;
  placeName: string;
  startTime: string;
  endTime: string;
  visitDurationMinutes: number;
  travelTimeFromPreviousMinutes: number;
  activityDescription: string;
}

export interface DayPlan {
  itinerary: ItineraryItem[];
  narrative: string;
  tips: string[];
  alternatives: {
    name: string;
    reason: string;
  }[];
}

export interface UserPreferences {
  interests: string[];
  availableHours: number;
  startTime: string;
  travelMode: 'DRIVING' | 'WALKING' | 'TRANSIT';
  startLocation: StartLocation;
}
